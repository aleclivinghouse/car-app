// import React from 'react';
// import axios from 'axios';
// import {connect} from 'react-redux';
// import {fetchMakes} from '../actions';
//
//
// class Makes extends React.Component{
//   constructor(props){
//     super(props);
//     this.state = {
//     }
//   }
//
// componentWillReceiveProps(nextProps){
//   this.props.fetchMakes(nextProps);
// }
//
//   render(){
//     return(
//       <div>Show makes/models</div>
//     );
//   }
// }
// export default connect(null, {fetchMakes})(Makes);
