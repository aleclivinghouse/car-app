export const SEND_FORM = 'SEND_FORM';
export const GET_ERRORS = 'GET_ERRORS';
export const ADD_SELECTED_CAR = "ADD_SELECTED_CAR";
export const DELETE_CARD = "DELETE_CARD";
export const ADD_MAX_MILES = "ADD_MAX_MILES";
export const ADD_MAX_PRICE = "ADD_MAX_PRICE";
export const FETCH_MAKES = "FETCH_MAKES";
